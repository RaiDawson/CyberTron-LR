from ultralytics import YOLO

# load model
model = YOLO("yolov8n.yaml") # build a new model from scratch

# Use the model
results = model.train(data="config.yaml", epochs=200, lr0=0.001) # train the model | lr0 = learning rate
