import os
import cv2
from ultralytics import YOLO

# Set video file paths relative to script location
VIDEO_FILENAME = 'letteraa.mp4'
VIDEO_PATH = os.path.join('.', VIDEO_FILENAME)
VIDEO_PATH_OUT = '{}_out.mp4'.format(os.path.splitext(VIDEO_FILENAME)[0])

# Check if the video file exists
if not os.path.exists(VIDEO_PATH):
    raise FileNotFoundError(f"Cannot find video file at {VIDEO_PATH}")

cap = cv2.VideoCapture(VIDEO_PATH)
if not cap.isOpened():
    raise IOError(f"Failed to open video file at {VIDEO_PATH}")

ret, frame = cap.read()
if not ret or frame is None:
    raise IOError(f"Failed to read the first frame from {VIDEO_PATH}")

H, W, _ = frame.shape
out = cv2.VideoWriter(VIDEO_PATH_OUT, cv2.VideoWriter_fourcc(*'mp4v'), int(cap.get(cv2.CAP_PROP_FPS)), (W, H))

# Adjust path to match your trained model location
MODEL_PATH = os.path.join('.', 'runs', 'detect', 'train2', 'weights', 'last.pt')
model = YOLO(MODEL_PATH)  # Load a custom trained YOLO model

threshold = 0.5

while ret and frame is not None:
    results = model(frame)[0]
    for result in results.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id = result
        if score > threshold:
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
            cv2.putText(
                frame,
                results.names[int(class_id)].upper(),
                (int(x1), int(y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.3,
                (0, 255, 0),
                3,
                cv2.LINE_AA
            )
    out.write(frame)
    ret, frame = cap.read()

cap.release()
out.release()
cv2.destroyAllWindows()
