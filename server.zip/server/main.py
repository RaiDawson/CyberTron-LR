import cv2
import requests
from ultralytics import YOLO
import numpy as np
from PIL import Image
import io
import time

class ESP32YOLODetector:
    def __init__(self, esp32_ip, model_path="yolov8n.pt"):
        # URL to ESP32's /frame endpoint
        self.esp32_url = f"http://192.168.100.104/frame"
        print("Loading YOLO model:", model_path)
        self.model = YOLO(model_path)
        print("Model loaded.")

    def get_frame(self):
        try:
            # Pull a single image from ESP32
            resp = requests.get(self.esp32_url, timeout=5)
            if resp.status_code == 200:
                image = Image.open(io.BytesIO(resp.content))
                frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
                return frame
            else:
                print("Bad response from ESP32:", resp.status_code)
                return None
        except Exception as e:
            print("Frame error:", e)
            return None

    def run(self):
        print("Starting YOLOv8 detection. Press 'q' to quit.")
        while True:
            frame = self.get_frame()
            if frame is None:
                print("No frame, retrying...")
                time.sleep(1)
                continue
            # Run YOLO detection
            results = self.model(frame)
            annotated = results[0].plot()
            cv2.imshow("ESP32 YOLOv8 Detection", annotated)
            # Print detection info
            boxes = results[0].boxes
            if len(boxes) > 0:
                print(f"Detected {len(boxes)} objects.")
                for box in boxes:
                    class_id = int(box.cls[0])
                    conf = float(box.conf[0])
                    name = self.model.names[class_id]
                    print(f"- {name}: {conf:.2f}")
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            time.sleep(0.1)
        cv2.destroyAllWindows()

def main():
    esp32_ip = "http://192.168.100.104"  # <-- Replace with your ESP32's IP!
    model_path = "C:/Users/marti/OneDrive/Desktop/python_yolo_model/runs/detect/train2/weights/best.pt"
    detector = ESP32YOLODetector(esp32_ip, model_path)
    detector.run()

if __name__ == "__main__":
    main()
